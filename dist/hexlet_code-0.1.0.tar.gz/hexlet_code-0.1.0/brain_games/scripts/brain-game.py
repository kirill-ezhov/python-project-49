from brain_games.brain_start  import run_game
from brain_games import arg_parser


def main():
    run_game(arg_parser.args_parser())


if __name__ == '__main__':
    main()