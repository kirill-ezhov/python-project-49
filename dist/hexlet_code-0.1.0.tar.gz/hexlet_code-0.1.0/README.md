 Brain games
---


Brain Games includes five math games:
- Parity Check
- Calculator
- Greatest Common Divisor
- Arithmetic Progression
- Prime Numbers

All games are started and played using the terminal.
Requirements

Requirements
---
- python, version 3.9 or higher
- poetry, version 1.0.0 or higher

Installation
Clone this repo:
```sh
git clone https://github.com/kirill-ezhov/python-project-49.git
```








brain_calc:
<a href="https://asciinema.org/a/W7Xa4raPv0IEdp0ZU54fu0A8j" target="_blank"><img src="https://asciinema.org/a/W7Xa4raPv0IEdp0ZU54fu0A8j.svg" /></a>

brain_even:
<a href="https://asciinema.org/a/MuYQfptWmp5JeaF27UN2I1YW1" target="_blank"><img src="https://asciinema.org/a/MuYQfptWmp5JeaF27UN2I1YW1.svg" /></a>

brain_gcd:
<a href="https://asciinema.org/a/CfTrsMqeWxUooNk7QUhyhQtBG" target="_blank"><img src="https://asciinema.org/a/CfTrsMqeWxUooNk7QUhyhQtBG.svg" /></a>

brain_prime:
<a href="https://asciinema.org/a/Pcpxz3wXqFQg15LgAUSO8p0pA" target="_blank"><img src="https://asciinema.org/a/Pcpxz3wXqFQg15LgAUSO8p0pA.svg" /></a>

brain_progression:
<a href="https://asciinema.org/a/N9G8jTAYQ2V0vjLDuotF2GCpM" target="_blank"><img src="https://asciinema.org/a/N9G8jTAYQ2V0vjLDuotF2GCpM.svg" /></a>
