def games():
    return None